import 'package:flutter/material.dart';
import 'generate_qr_screen.dart';
import 'student_model.dart';

class StudentListScreen extends StatelessWidget {
  final List<Student> students = [
    Student(id: '1', name: 'John Doe'),
    Student(id: '2', name: 'Jane Doe'),
    // Add more students
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Student List'),
      ),
      body: ListView.builder(
        itemCount: students.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(students[index].name),
            subtitle: Text('ID: ${students[index].id}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      GenerateQRScreen(student: students[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
