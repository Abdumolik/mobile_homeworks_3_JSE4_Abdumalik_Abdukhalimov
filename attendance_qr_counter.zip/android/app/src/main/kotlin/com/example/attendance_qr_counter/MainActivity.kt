package com.example.attendance_qr_counter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
