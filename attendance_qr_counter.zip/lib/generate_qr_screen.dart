import 'package:flutter/material.dart';
import 'student_model.dart';

class GenerateQRScreen extends StatelessWidget {
  final Student student;

  GenerateQRScreen({required this.student});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Generate QR Code'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl=${Uri.encodeComponent(student.id)}',
            ),
            SizedBox(height: 20.0),
            Text('Student ID: ${student.id}'),
          ],
        ),
      ),
    );
  }
}
